import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# Define your dataset folder path
dataset_folder = 'my_dataset'

# Use ImageDataGenerator for data preprocessing and augmentation
datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

# Define training dataset
train_generator = datagen.flow_from_directory(
    dataset_folder,
    target_size=(224, 224),  # adjust based on your input size
    batch_size=32,
    class_mode='binary',  # adjust based on your task (binary, categorical, etc.)
    subset='training'
)

# Define validation dataset
validation_generator = datagen.flow_from_directory(
    dataset_folder,
    target_size=(224, 224),
    batch_size=32,
    class_mode='binary',
    subset='validation'
)

# Build a simple convolutional neural network (CNN)
model = models.Sequential()
model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(224, 224, 3)))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Conv2D(64, (3, 3), activation='relu'))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Conv2D(128, (3, 3), activation='relu'))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Flatten())
model.add(layers.Dense(128, activation='relu'))
model.add(layers.Dense(1, activation='sigmoid'))  # for binary classification

# Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train the model
history = model.fit(train_generator, epochs=10, validation_data=validation_generator)